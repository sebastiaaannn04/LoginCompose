package com.example.myapplication.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.MaterialTheme
import androidx.compose.material.darkColors
import androidx.compose.material.lightColors
import androidx.compose.runtime.Composable

private val DarkColorPalette = darkColors(
    primary = BLUE900,
    primaryVariant = BLUE950,
    secondary = CYAN900,
    secondaryVariant=CYAN800,
    background=BLUEGREY900,
    surface=BLUEGREY800,
    error=REDD800


)

private val LightColorPalette = lightColors(
    primary = BLUE500,
    primaryVariant = BLUE800,
    secondary = CYAN500,
    secondaryVariant=CYAN700,
    background=LIGHTBLUE50,
    surface=LIGHTBLUE100,
    error=RED800

    /* Other default colors to override
    background = Color.White,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black,
    */
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) {
        DarkColorPalette
    } else {
        LightColorPalette
    }

    MaterialTheme(
        colors = colors,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}