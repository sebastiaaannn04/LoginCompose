package com.example.myapplication.Models

data class Encendedores(
    var id:Int,
    var nombre:String,
    var precio:String,
    var foto:Int,
)
