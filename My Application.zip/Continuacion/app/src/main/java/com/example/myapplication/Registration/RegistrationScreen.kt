package com.example.myapplication.Registration

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.Components.RoundedButton
import com.example.myapplication.Components.TransparentTextField
import com.example.myapplication.Navegacion.Destinations

@Composable
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
fun RegistrationScreen(

    navController: NavController,
    state: RegisterState,
    onRegister: (nameValue: String, emailValue: String, phoneValue: String, passValue: String, confirmPassValue: String) -> Unit,
    onBack: ()-> Unit,
    onDismissDialog:()->Unit
){

    val nameValue=remember{ mutableStateOf("") }
    val emailValue=remember{ mutableStateOf("") }
    val phoneValue=remember{ mutableStateOf("") }
    val passValue=remember{ mutableStateOf("") }
    val confirmPassValue=remember{ mutableStateOf("") }

    var passwordVisibility by remember{ mutableStateOf(false) }
    var confirmPasswordVisibility by remember{ mutableStateOf(false) }


    val focusManager= LocalFocusManager.current

    Box(modifier = Modifier.fillMaxWidth()) {

        Column(modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())) {

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {navController.navigate(route = Destinations.LoginScreen.route)}) {
                    Icon(imageVector= Icons.Default.ArrowBack,contentDescription= "Regresar al login",
                    tint=MaterialTheme.colors.primary)
                }
                Text( text="Crear una cuenta nueva.", style = MaterialTheme.typography.h6.copy(
                    color=MaterialTheme.colors.primary
                ))
            }//Fin de la fila inicial

            Column(modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {

                TransparentTextField( //Texto nombre
                    textFieldValue = nameValue,
                    textLabel = "Name",
                    keyboardType = KeyboardType.Text,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )

                TransparentTextField( //Texto correo
                    textFieldValue = emailValue,
                    textLabel = "Correo",
                    keyboardType = KeyboardType.Email,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )

                TransparentTextField( //Texto Telefono
                    textFieldValue = phoneValue,
                    textLabel = "Telefono",
                    keyboardType = KeyboardType.Phone,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )

                TransparentTextField( //Texto Clave
                    textFieldValue = passValue,
                    textLabel = "Password",
                    keyboardType = KeyboardType.Password,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next,
                    trailingIcon={
                        IconButton(
                            onClick = {
                            passwordVisibility=!passwordVisibility
                        }) {
                        Icon(
                            imageVector = if(passwordVisibility){
                                Icons.Default.Visibility
                            }else{
                                Icons.Default.VisibilityOff
                            },
                            contentDescription = "Toggle"
                            )
                        }
                    },//Fin del trailingicon
                visualTransformation = if(passwordVisibility){
                    VisualTransformation.None
                }else {
                    PasswordVisualTransformation()
                }
        )// Fin de la clave

                TransparentTextField( //Texto Confirmar clave
                    textFieldValue = confirmPassValue,
                    textLabel = "Confirmar Password",
                    keyboardType = KeyboardType.Password,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManager.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Done,
                    trailingIcon={
                        IconButton(
                            onClick = {
                                confirmPasswordVisibility=!confirmPasswordVisibility
                            }) {
                            Icon(
                                imageVector = if(confirmPasswordVisibility){
                                    Icons.Default.Visibility
                                }else{
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Toggle"
                            )
                        }
                    },//Fin del trailingicon
                    visualTransformation = if(confirmPasswordVisibility){
                        VisualTransformation.None
                    }else {
                        PasswordVisualTransformation()
                    }

                )//Fin confirmar clave

                Spacer(modifier = Modifier.height(16.dp) )// Espacio
                RoundedButton(
                    text ="SingUp",
                    displayProgressBar = false,
                    onClick = {
                        navController.navigate(route=Destinations.Inicio.route)
                    }
                )//Boton de singUp

                ClickableText(text = buildAnnotatedString {
                    append("Already have Acount")
                    withStyle(
                        style = SpanStyle(
                            color=MaterialTheme.colors.primary,
                        fontWeight = FontWeight.Bold                        )
                    ){
                        append("LogIn")
                    }
                },
                    onClick ={navController.navigate(route=Destinations.LoginScreen.route)} )//Allreadyhave acount
            }//Fin de la columna interior

            Spacer(modifier = Modifier.height(16.dp))//Espacio
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row (
                    modifier=Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ){
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness=1.dp,
                        color= Color.Gray)//Linea divisora

                    Text( modifier = Modifier.height(8.dp),
                        text="OR",
                        style=MaterialTheme.typography.h6.copy(fontWeight = FontWeight.Black)
                    )//Line or

                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness=1.dp,
                        color= Color.Gray)//Linea divisora
                    } //END ROW
                 }//End Column
        }// Fin Columna
        
    }//Fin Box
}//Fin Functio


