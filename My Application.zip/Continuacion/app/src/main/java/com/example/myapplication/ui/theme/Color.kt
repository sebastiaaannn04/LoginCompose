package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color


//Blue ligth palete

val BLUE500= Color(0xFF2196f3) //Primary
val BLUE800= Color(0xFF0277BD) //PrimaryVariant
val CYAN500= Color(0XFF00bcd4) //Secondary
val CYAN700= Color(0Xff008ba3) //SecondaryVariant
val LIGHTBLUE50= Color(0xffe1f5fe) //Background
val LIGHTBLUE100= Color(0xffb3e5fc)//Surface
val RED800=Color(0xffba000d)//Error


//Blue dark palete

val BLUE900= Color(0xFF0d47a1) //Primary
val BLUE950= Color(0xFF002171) //PrimaryVariant
val CYAN900= Color(0XFF006064) //Secondary
val CYAN800= Color(0Xff428e92) //Secondary Variant
val BLUEGREY900= Color(0xff000a12) //Background
val BLUEGREY800= Color(0xff263238)//Surface
val REDD800=Color(0xffba000d)//Error


