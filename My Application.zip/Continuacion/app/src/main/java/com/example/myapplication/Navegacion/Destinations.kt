package com.example.myapplication.Navegacion

sealed class Destinations(
    val route :String
){
    object LoginScreen:Destinations(route = "LoginScreen/{nameVlue}"){
        fun crearRouteNueva(nameValue:String):String{
            return "LoginScreen/$nameValue"
        }
    }
    object RegistrationScreen:Destinations(route="RegistrationScreen")
    object ForgotPassword:Destinations(route="ForgotPassword")
    object Compras:Destinations(route="Compras")
    object Inicio:Destinations(route="Inicio/{User}"){
        fun crearRoute(user:String):String{
            return "Inicio/$user"
        }
    }

}
