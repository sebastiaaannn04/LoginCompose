package com.example.myapplication.Screens


import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.Models.Encendedores
import com.example.myapplication.Models.encendedores
import com.example.myapplication.Navegacion.Destinations

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Compras( navController: NavController){
    Scaffold(
        topBar = {
            TopAppBar() {
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Back",
                    modifier = Modifier.clickable {
                        navController.navigate(route = Destinations.Inicio.route)
                    }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "ENCENDEDORES ",
                    modifier = Modifier.clickable {
                        navController.navigate(route = Destinations.Inicio.route)
                    })
            }
        }
    ) {

        ListaEncendedores(encendedores, navController)
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "")
        Button(onClick = {
            navController.navigate(route = Destinations.Inicio.route)
        }) {
            Text(text = "Volver a la pagina principal")
        }
    }


}


@Composable
fun ListaEncendedores(encendedores : List<Encendedores>, navController: NavController){
    LazyColumn(){
      items(encendedores){
            encendedor-> EncendedoresCard(encendedor.id, encendedor.nombre, encendedor.precio, encendedor.foto, navController)
    }
   }
 }

@Composable
fun EncendedoresCard(id: Int, nombre: String, precio:String, foto: Int, navController: NavController){
    Row(modifier = Modifier.padding(all = 8.dp)) {
        Image(
            painter = painterResource(foto),
            contentDescription = null,
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .border(1.5.dp, MaterialTheme.colors.secondaryVariant, CircleShape)
        )

        Spacer(modifier = Modifier.width(8.dp))

        var isExpanded by remember { mutableStateOf(false) }

        Column(modifier = Modifier.clickable { isExpanded = !isExpanded }) {
            Text(text = id.toString(), color = MaterialTheme.colors.secondaryVariant,
                style = MaterialTheme.typography.subtitle2)

            Spacer(modifier = Modifier.height(4.dp))

            Surface(shape = MaterialTheme.shapes.medium,
                elevation = 1.dp)
            {
                Text(
                    text = nombre,
                    modifier = Modifier.padding(all = 4.dp),
                    style = MaterialTheme.typography.body2,
                    maxLines= if (isExpanded) Int.MAX_VALUE else 1
                )

            }
            Surface(shape = MaterialTheme.shapes.medium,
                elevation = 1.dp)
            {

                Surface(shape = MaterialTheme.shapes.medium,
                    elevation = 1.dp)
                {
                    Text(
                        text = precio,
                        modifier = Modifier.padding(all = 4.dp),
                        style = MaterialTheme.typography.body2,
                        maxLines= if (isExpanded) Int.MAX_VALUE else 1
                    )
                }
            }
            Button(onClick = {
                navController.navigate(route = Destinations.Compras.route)
            }) {
                Text(text = "Ir a pagar")
            }

        }
    }

}



