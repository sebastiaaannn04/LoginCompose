package com.example.myapplication.Models

import com.example.myapplication.R

var encendedores= listOf(

    Encendedores(
        id=1, nombre = "Dragon:                                                          Es un encendedor especial con diseño en labrado de dragon y acabados en tinta negra de la mas alya calidadcon diseño en labrado de dragon y acabados en tinta negra de la mas alya calidadcon diseño en labrado de dragon y acabados en tinta negra de la mas alya calidadcon diseño en labrado de dragon y acabados en tinta negra de la mas alya calidadcon diseño en labrado de dragon y acabados en tinta negra de la mas alya calidadcon diseño en labrado de dragon y acabados en tinta negra de la mas alya calidadcon diseño en labrado de dragon y acabados en tinta negra de la mas alya calidad ", precio="60.000", foto= R.drawable.dragon
    ),Encendedores(
        id=2, nombre = "Marrano", precio="50.000", foto= R.drawable.marrano
    ),Encendedores(
        id=3, nombre = "Tigre", precio="70.000", foto= R.drawable.tigre
    ),Encendedores(
        id=4, nombre = "Sencillo", precio="20.000", foto= R.drawable.sencillo
    ),Encendedores(
        id=5, nombre = "Cuero", precio="25.000", foto= R.drawable.cuero
    ),Encendedores(
        id=6, nombre = "Licor", precio="30.000", foto= R.drawable.licor
    ),Encendedores(
        id=7, nombre = "RGB", precio="80.000", foto= R.drawable.gamer
    ),Encendedores(
        id=8, nombre = "Linterna", precio="50.000", foto= R.drawable.linterna
    ),Encendedores(
        id=9, nombre = "Electrico", precio="100.000", foto= R.drawable.electronico
    ),Encendedores(
        id=10, nombre = "Decoracion", precio="115.000", foto= R.drawable.electricoespecial
    ),



)