package com.example.myapplication.Presentacion.login

import android.graphics.drawable.Icon
import android.media.Image
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.FocusRequester.Companion.createRefs
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role.Companion.Image
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import com.example.myapplication.Components.RoundedButton
import com.example.myapplication.Components.TransparentTextField
import com.example.myapplication.R
import androidx.navigation.NavController
import com.example.myapplication.Navegacion.Destinations
import com.example.myapplication.Navegacion.Destinations.LoginScreen.route
import com.example.myapplication.Navegacion.Destinations.RegistrationScreen
import com.example.myapplication.Navegacion.AppNavigation
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlin.reflect.KFunction

@Composable
fun LoginScreen(
    navController: NavController,
    state:LoginState,
    onLogin:(dato1: String, dato2: String)->Unit,
    onNavigateRegister:()->Unit,
    onNavigateForgot:()->Unit,
    onDismissDialog:KFunction<Unit>,

){

    val emailValue=rememberSaveable{
        mutableStateOf("")
    }
    val passwordValue=rememberSaveable{
        mutableStateOf("")

    }
    var passwordVisibility by remember{
        mutableStateOf(false)

    }
    val focusManager= LocalFocusManager.current




    Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.background)
       ){
            Image(painter= painterResource(id = R.drawable.ferxxo),
            contentDescription="Imagen Usurio",
            contentScale = ContentScale.Inside)
        Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.BottomCenter
        ){
            ConstraintLayout() {

                val(surface,fab)= createRefs()
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(400.dp)
                        .constrainAs(surface) {
                            bottom.linkTo(parent.bottom)
                        },
                    color=Color.White,
                    shape = RoundedCornerShape(
                        topStartPercent = 8,
                        topEndPercent = 8)
                ) {
                    Column(modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                    ){
                        Text(text ="Bienvenido",
                        style=MaterialTheme.typography.h4.copy(
                            fontWeight = FontWeight.Medium
                           )
                        )
                        Text(text="Accede a tu cuenta",
                            style=MaterialTheme.typography.h4.copy(
                                fontWeight = FontWeight.Medium
                            )
                        )

                        Column(
                            modifier= Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ){
                            TransparentTextField(
                                textFieldValue = emailValue,
                                textLabel = "eMail",
                                keyboardType = KeyboardType.Email,
                                keyboardActions = KeyboardActions(
                                    onNext={
                                        focusManager.moveFocus(FocusDirection.Down)
                                    }
                                ) ,
                                imeAction = ImeAction.Next
                            )
                            TransparentTextField(
                                textFieldValue = passwordValue,
                                textLabel = "Password",
                                keyboardType = KeyboardType.Password,
                                keyboardActions = KeyboardActions(
                                    onDone ={
                                        focusManager.clearFocus()
                                        //TODO
                                    }
                                ) ,
                                imeAction = ImeAction.Done,
                                trailingIcon={
                                    IconButton(
                                        onClick = {
                                            passwordVisibility = !passwordVisibility
                                        }
                                    )
                                    {
                                        Icon(
                                            imageVector = if (passwordVisibility){
                                                Icons.Default.Visibility
                                            }else{
                                                 Icons.Default.VisibilityOff
                                            },
                                        contentDescription="Toggle"
                                        )
                                    }
                                },//Fin del trailingnicon
                            visualTransformation = if (passwordVisibility){
                                VisualTransformation.None
                            }else {
                                PasswordVisualTransformation()
                              }
                            )
                            Text(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { navController.navigate(route=Destinations.ForgotPassword.route)},
                                text="forgot password",
                                style=MaterialTheme.typography.body1,
                                textAlign = TextAlign.End
                            )
                        }//Fin de la columna interna

                        Column(
                        modifier=Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                        RoundedButton(
                                text = "Login",
                            displayProgressBar = false,
                            onClick={
                                navController.navigate(route = Destinations.Inicio.route)
                            }
                        )//Fin del button
                        
                        ClickableText(text = buildAnnotatedString {
                            append("No tiene una cuenta activa?")
                            withStyle(
                                style = SpanStyle(
                                    color = MaterialTheme.colors.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            ){
                                append("singUp")
                            }
                        },
                            onClick = {
                                navController.navigate(route = Destinations.ForgotPassword.route)
                            }
                        )
                      }//fin de la 2 columna

                    }//Fin de la columna
                }//Fin del surface
                FloatingActionButton(
                    modifier = Modifier
                        .size(72.dp)
                        .constrainAs(fab) {
                            top.linkTo(surface.top, margin = (-36).dp)
                            end.linkTo(surface.end, margin = 36.dp)
                        },


                    backgroundColor = MaterialTheme.colors.primary,
                    onClick = {navController.navigate(route = Destinations.RegistrationScreen.route)}
                ) {

                    Icon(
                        modifier=Modifier.size(72.dp),
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Boton de avanzar",
                        tint=Color.White

                    )

                }//Foin del floatingbhuton
            }//Fin del constrainlayout
        }//Fin del box interno
    }//Fin del box



}//Fin del function







