package com.example.myapplication.Screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.Navegacion.Destinations

@Composable
fun Inicio(navController: NavController, user:String){
    Text(text = "Hola $user")
    
    
    Column (modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)){

        IconButton(onClick = {navController.navigate(route = Destinations.LoginScreen.route)}) {
            Icon(
                imageVector = Icons.Default.ArrowBack, contentDescription = "Regresar al login",
                tint = MaterialTheme.colors.primary
            )
        }

        Text(text ="Bienvenido!!",
            style= MaterialTheme.typography.h4.copy(
                fontWeight = FontWeight.Medium
            )
        )
        Text(text="Elije que qiueres comprar hoy",
            style= MaterialTheme.typography.h4.copy(
                fontWeight = FontWeight.Medium
            )
        )

        Button(onClick = ({navController.navigate(route = Destinations.Compras.route)}))
        {
Text(text = "Ingresar a la tienda ")
        }

    }
}