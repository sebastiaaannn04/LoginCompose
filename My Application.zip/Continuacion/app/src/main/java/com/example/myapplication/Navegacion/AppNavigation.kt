package com.example.myapplication.Navegacion

import androidx.compose.compiler.plugins.kotlin.EmptyFunctionMetrics.composable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.myapplication.Presentacion.login.LoginScreen
import com.example.myapplication.Presentacion.login.LoginViewModel
import com.example.myapplication.Registration.RegisterViewModel
import com.example.myapplication.Registration.RegistrationScreen
import com.example.myapplication.Screens.*

@Composable
fun AppNavigation(){
    val navController= rememberNavController()
    NavHost(
        navController= navController,
        startDestination = Destinations.LoginScreen.route
    ){
val viewModel= LoginViewModel()
            composable(route=Destinations.LoginScreen.route){
                if (viewModel.state.value.successLogin){
                    LaunchedEffect(key1 = Unit) {
                    navController.navigate(Destinations.Inicio.crearRoute(viewModel.state.value.email))
                        ///modificamos el historial de navegacion para no poder regresar
                        {
                            popUpTo(Destinations.LoginScreen.route) {
                                inclusive = true
                            }//fin popup
                        }//fin modificacion
                    }//fin launcheffect
                } else {
                    LoginScreen(
                        navController,
                        state = viewModel.state.value,
                        onLogin = viewModel::login,
                        onNavigateRegister = { navController.navigate(Destinations.RegistrationScreen.route) },
                        onNavigateForgot = { navController.navigate(Destinations.ForgotPassword.route) },
                        onDismissDialog = viewModel::hideErrorDialog
                     )
                    }//fin if
                }// Fin

        val viewModel2= RegisterViewModel()
            composable("RegistrationScreen"){
                RegistrationScreen(

                    navController,
                    state=viewModel2.state.value,
                    onRegister=viewModel2::register,
                    onBack={navController.popBackStack()},
                    onDismissDialog=viewModel2::hideErrorDialog
                )
            }
            composable(
                route=Destinations.Inicio.route,
                arguments = listOf(navArgument("user")
                {
                    type= NavType.StringType
                })
            )  {
               Inicio(navController=navController, user=it.arguments?.getString("user") ?:"")
            }
    }




}